sap.ui.define([
	"com/swl/Y20_OBD_TR_PRP1/test/unit/controller/Main.controller"
], function () {
	"use strict";
});