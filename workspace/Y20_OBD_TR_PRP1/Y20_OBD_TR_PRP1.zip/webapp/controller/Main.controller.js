sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.swl.Y20_OBD_TR_PRP1.controller.Main", {
		onInit: function () {

		}
	});
});