sap.ui.define([
	"com/swl/GridLayout_Template/test/unit/controller/Main.controller"
], function () {
	"use strict";
});