sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageStrip",
	"sap/base/Log",
	"sap/ui/model/json/JSONModel",
	"./BaseController",
	"sap/ui/core/library",
	"sap/ui/core/message/Message",
	"sap/m/MessageToast"
], function (Controller, MessageStrip, Log, JSONModel, BaseController, Library, Message, MessageToast) {
	"use strict";

	var MessageType = Library.MessageType;

	return BaseController.extend("com.swl.DECO_ASSIGN_HU_TROLLEY.controller.Main", {
		onInit: function () {

			//Set the jsonModel for all Elements of the screen
			var oModelData = new sap.ui.model.json.JSONModel();
			oModelData.loadData("model/Elements.json");
			this.getView().setModel(oModelData, "ELEMENTS");
			//			this.initElementsModel();
			//Set the jsonModel for the header elements of the screen
			//			this.initHeaderModel();
			//Set the Message model
			this.initMessageModel();
		},

		onBeforeRendering: function () {
			//	sap.base.Log.info("Method onBeforeRendering");
			var oMs = sap.ui.getCore().byId("msgStrip");
			//debugger

			if (oMs) {
				oMs.destroy();
			}
			// this.buildStorageBin();
		},

		initView: function () {
			this.getView().invalidate();

		},
		
		_clearMessage: function() {
			var oMs = sap.ui.getCore().byId("msgStrip");
			//debugger

			if (oMs) {
				oMs.destroy();
			}
		},

		onDeviation: function () {
			this.showMessage("No Deviation Popup implemented", MessageType.Error);
		},

		onClose: function () {
			this.showMessage("No logic implemented", MessageType.Information);
		},

		onScanHU: function () {
			//debugger;
			this._clearMessage();
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			//var oModelHU = this.getView().getModel();
			var that = this;

			var oModel = this.getView().getModel("odata");
			//var propertyString = "/Button2" + "/text";
			var huident = event.srcElement.value;
			var lgnum = "TMPL";
			//oModel.read("/ScanHandlingUnitSet(Lgnum='" + lgnum + "',ScanHU='" + huident + "')?$expand=ScanHU_HUNav", {
					oModel.read("/ScanHandlingUnitSet(Lgnum='" + lgnum + "',ScanHU='" + huident + "')", { urlParameters: { $expand: "ScanHU_HUNav" } }, {
					success: function (oData, response) {
						//Log.info(response);
						var oText = oResourceBundle.getText("HU_READ_SUCCESS", huident);
						var oMessage = new Message({
							message: oText,
							type: MessageType.Success,
							target: "/Dummy" //,
								//processor: view.getModel()
						});
						sap.ui.getCore().getMessageManager().addMessages(oMessage);

						MessageToast.show(oText);

						var form = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--FormHU");
						form.bindElement({
							path: "/ScanHandlingUnitSet(Lgnum='" + oData.Lgnum + "',ScanHU='" + oData.ScanHU + "')/ScanHU_HUNav",
							model: "odata"
						});

						sap.ui.getCore().byId("container-com.swl---Main--innergrid2--scanPos").focus();
						that.enableElement("btn_info");

					},
					error: function (oError) {
						var form = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--FormHU");
						form.unbindElement("odata");

						//var oMsg = JSON.parse(oError.responseText);
						var oInputHU = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU");
						var oMsg = oResourceBundle.getText("HU_READ_FAIL", oInputHU.getValue());
						var oHL = sap.ui.getCore().byId("container-com.swl---Main--footer--hbox1");
						var oMs = sap.ui.getCore().byId("msgStrip");

						if (oMs) {
							oMs.destroy();
						}

						var oMsgStrip = new sap.m.MessageStrip("msgStrip", {
							text: oMsg,
							showCloseButton: false,
							showIcon: false,
							type: "Error"
						});
						oHL.addItem(oMsgStrip);
						oInputHU.setValue("");

						that.disableElement("btn_info");
					}
				}

			);
			//oModel.refresh(true);
		},

		onScanTrolley: function () {
			//debugger;
			this._clearMessage();
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var that = this;
			var oInputHU = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU");
			
			if(oInputHU.getValue().length === 0) {
						var oText = oResourceBundle.getText("NO_HU_SCANNED");
						this.showMessage(oText, MessageType.Error);
						return;
			}
			
			var oModel = this.getView().getModel("odata");
			var oModelJson = this.getView().getModel("trolley");

			//var propertyString = "/Button2" + "/text";
			var trolley = event.srcElement.value;
			var lgnum = "TMPL";
			var request = {
					"Lgnum": "TMPL",
					"ScanTrolley": trolley,
					"ScanTrolley_TrolleyNav": {
						"LastHU": {
							"HUGuid": "00000000-0000-0000-0000-000000000000",
							"HUIdent": oInputHU.getValue(),
							"HUType": "",
							"PackMat": {
								"MatID": "00000000-0000-0000-0000-000000000000",
								"MatNR": ""
							}
						},
						"Lgnum": "TMPL",
						"Trolley": trolley
					},
					"ScanTrolley_TrolleyContentNav": {
						"results": [{}]
					}
			};
			oModel.create("/ScanTrolleySet", request, {
					//oModel.read("/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='" + trolley + "')?$expand=ScanTrolley_TrolleyNav,ScanTrolley_TrolleyContentNav", {
					//oModel.read("/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='" + trolley + "')?$expand=ScanTrolley_TrolleyNav", {
					success: function (oData, response) {
						//Log.info(response);
						var oHU = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU");
						var oText = oResourceBundle.getText("HU_PACKED_TO_TROLLEY_SUCCESS", [oHU.getValue(), trolley] );
						var oMessage = new Message({ 
							message: oText,
							type: MessageType.Success,
							target: "/Dummy" //,
								//processor: view.getModel()
						});
						sap.ui.getCore().getMessageManager().addMessages(oMessage);
						
						MessageToast.show(oText);
						//oModel.refresh(true);
						oModelJson.setData(oData);
						oModelJson.refresh(true);
						var prop = oModel.getProperty("/ScanTrolleySet(Lgnum='" + oData.Lgnum + "',ScanTrolley='" + oData.ScanTrolley + "')/ScanTrolley_TrolleyContentNav");
						// that.getView().bindElement({
						// 	path : "ScanTrolleySet",
						// 	parameters : {
						// 		"expand" : "ScanTrolley_TrolleyContentNav"
						// 	}
						// });
						var formTrolley = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--FormTrolley");
						//formTrolley.setModel(oModel);
						 formTrolley.bindElement({
						 	path: "/ScanTrolleySet(Lgnum='" + oData.Lgnum + "',ScanTrolley='" + oData.ScanTrolley + "')/ScanTrolley_TrolleyNav",
						 	model: "odata"
//						 	path: "ScanTrolleySet",
						 //parameters : {
							// 	"expand" : "ScanTrolley_TrolleyNav"
							// }
						});

						var trolleyCont = sap.ui.getCore().byId("container-com.swl---Main--innergrid3--TblTrolleyContent");
						//column list item creation
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{Position}"
							}), new sap.m.Text({
								text: "{Product/MatNR}"
							}), new sap.m.Text({
								text: "{HU/HUIdent}"
							}), new sap.m.Text({
								text: "{HU/HUType}"
							}), new sap.m.Text({
								text: "{Quantity/Quan} {Quantity/Unit}"
							})]
						});
					
						trolleyCont.setModel(oModel);
							//trolleyCont.bindRows( { path: "/ScanTrolley_TrolleyContentNav", oTemplate);
							//trolleyCont.bindItems("/ScanTrolley_TrolleyContentNav", oTemplate);
						 trolleyCont.bindAggregation("items", {
						 	path: "/ScanTrolleySet(Lgnum='" + oData.Lgnum + "',ScanTrolley='" + oData.ScanTrolley + "')/ScanTrolley_TrolleyContentNav",
						 	//path: "/ScanTrolley_TrolleyContentNav/results",
						 	template: oTemplate
						 }); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");

						var form = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--FormHU");
						form.unbindElement("odata");
						
						oHU.setValue("");

						sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU").focus();
						that.enableElement("btn_closeTrolley");
						
						
					},
					error: function (oError) {
						var formTrolley = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--FormTrolley");
						formTrolley.unbindElement("odata");

						var trolleyCont = sap.ui.getCore().byId("container-com.swl---Main--innergrid3--TblTrolleyContent");
						//column list item creation
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{Position}"
							}), new sap.m.Text({
								text: "{Product/MatNR}"
							}), new sap.m.Text({
								text: "{HU/HUIdent}"
							}), new sap.m.Text({
								text: "{HU/HUType}"
							}), new sap.m.Text({
								text: "{Quantity/Quan} {Quantity/Unit}"
							})]
						});

						trolleyCont.setModel(oModel);
						trolleyCont.bindAggregation("items", {
							path: "/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='" + trolley + "')/ScanTrolley_TrolleyContentNav",
							template: oTemplate
						}); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");
						//trolleyCont.unbindAggregation("items");
						that.disableElement("btn_closeTrolley");

						//var oMsg = JSON.parse(oError.responseText);
						var oInput1 = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--scanPos");
						var oHU = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU");
						var oText = oResourceBundle.getText("HU_PACKED_TO_TROLLEY_FAIL", [oHU.getValue(), oInput1.getValue()] );
						this.showMessage(oText,MessageType.Error);
					}
				}

			);
			oModel.refresh(true);
		},

		onCloseTrolley: function () {
			//debugger;
			this._clearMessage();
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			//var oModelHU = this.getView().getModel();
			var that = this;

			var oModel = this.getView().getModel("odata");
			//var propertyString = "/Button2" + "/text";
			var huident = event.srcElement.value;
			var lgnum = "TMPL";
			var request = {
				"Lgnum": lgnum,
				"UserCommand": "04",
				"UserCommand_TrolleyNav": {
					"LastHU": {
						"HUGuid": "00000000-0000-0000-0000-000000000000",
						"HUIdent": "",
						"HUType": "",
						"PackMat": {
							"MatID": "00000000-0000-0000-0000-000000000000",
							"MatNR": ""
						}
					},
					"Lgnum": "",
					"Trolley": "",
					"ActivArea": "",
					"WarehouseTask": "000000000000"
				}
			};
			oModel.create("/UserCommandEntCollection", request, {
					//oModel.read("/ScanHandlingUnitSet(Lgnum='" + lgnum + "',ScanHU='" + huident + "')", { urlParameters: { "$expand":"ScanHU_HUNav" } }, {
					success: function (oData, response) {
						//Log.info(response);
						var oInput1 = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--scanPos");
						var oText = oResourceBundle.getText("TROLLEY_CLOSE_SUCCESS", oInput1.getValue());
						var oMessage = new Message({
							message: oText,
							type: MessageType.Success,
							target: "/Dummy" //,
								//processor: view.getModel()
						});
						sap.ui.getCore().getMessageManager().addMessages(oMessage);

						MessageToast.show(oText);

						var formTrolley = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--FormTrolley");
						formTrolley.unbindElement("odata");

						var trolleyCont = sap.ui.getCore().byId("container-com.swl---Main--innergrid3--TblTrolleyContent");
						//column list item creation
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{Position}"
							}), new sap.m.Text({
								text: "{Product/MatNR}"
							}), new sap.m.Text({
								text: "{HU/HUIdent}"
							}), new sap.m.Text({
								text: "{HU/HUType}"
							}), new sap.m.Text({
								text: "{Quantity/Quan} {Quantity/Unit}"
							})]
						});

						trolleyCont.setModel(oModel);
						trolleyCont.unbindAggregation("items", {
							path: "/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='')/ScanTrolley_TrolleyContentNav",
							template: oTemplate
						}); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");
						// trolleyCont.unbindAggregation("items", {
						// 	template: oTemplate
						// }); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");

						that.disableElement("btn_closeTrolley");
						oInput1.setValue("");
						sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU").focus();

					},
					error: function (oError) {
						var formTrolley = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--FormTrolley");
						formTrolley.unbindElement("odata");

						var trolleyCont = sap.ui.getCore().byId("container-com.swl---Main--innergrid3--TblTrolleyContent");
						//column list item creation
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{Position}"
							}), new sap.m.Text({
								text: "{Product/MatNR}"
							}), new sap.m.Text({
								text: "{HU/HUIdent}"
							}), new sap.m.Text({
								text: "{HU/HUType}"
							}), new sap.m.Text({
								text: "{Quantity/Quan} {Quantity/Unit}"
							})]
						});

						trolleyCont.setModel(oModel);
						trolleyCont.bindAggregation("items", {
							path: "/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='')/ScanTrolley_TrolleyContentNav",
							template: oTemplate
						}); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");
						//trolleyCont.unbindAggregation("items");

						//var oMsg = JSON.parse(oError.responseText);
						var oInput1 = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--scanPos");
						var oMsg = oResourceBundle.getText("TROLLEY_CLOSE_FAIL", oInput1.getValue());
						this.showMessage(oMsg, MessageType.Error);
						that.disableElement("btn_closeTrolley");
					}
				}

			);
			oModel.refresh(true);
		},

		onCloseAllTrolley: function () {
			//debugger;
			this._clearMessage();
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			//var oModelHU = this.getView().getModel();
			var that = this;

			var oModel = this.getView().getModel("odata");
			//var propertyString = "/Button2" + "/text";
			var huident = event.srcElement.value;
			var lgnum = "TMPL";
			var request = {
				"Lgnum": lgnum,
				"UserCommand": "05",
				"UserCommand_TrolleyNav": {
					"LastHU": {
						"HUGuid": "00000000-0000-0000-0000-000000000000",
						"HUIdent": "",
						"HUType": "",
						"PackMat": {
							"MatID": "00000000-0000-0000-0000-000000000000",
							"MatNR": ""
						}
					},
					"Lgnum": "",
					"Trolley": "",
					"ActivArea": "",
					"WarehouseTask": "000000000000"
				}
			};
			oModel.create("/UserCommandEntCollection", request, {
					//oModel.read("/ScanHandlingUnitSet(Lgnum='" + lgnum + "',ScanHU='" + huident + "')", { urlParameters: { "$expand":"ScanHU_HUNav" } }, {
					success: function (oData, response) {
						//Log.info(response);
						var oInput1 = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--scanPos");
						var oText = oResourceBundle.getText("TROLLEY_CLOSEALL_SUCCESS");
						var oMessage = new Message({
							message: oText,
							type: MessageType.Success,
							target: "/Dummy" //,
								//processor: view.getModel()
						});
						sap.ui.getCore().getMessageManager().addMessages(oMessage);

						MessageToast.show(oText);

						var formTrolley = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--FormTrolley");
						formTrolley.unbindElement("odata");

						var trolleyCont = sap.ui.getCore().byId("container-com.swl---Main--innergrid3--TblTrolleyContent");
						//column list item creation
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{Position}"
							}), new sap.m.Text({
								text: "{Product/MatNR}"
							}), new sap.m.Text({
								text: "{HU/HUIdent}"
							}), new sap.m.Text({
								text: "{HU/HUType}"
							}), new sap.m.Text({
								text: "{Quantity/Quan} {Quantity/Unit}"
							})]
						});

						trolleyCont.setModel(oModel);
						trolleyCont.bindAggregation("items", {
							path: "/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='')/ScanTrolley_TrolleyContentNav",
							template: oTemplate
						}); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");

						that.disableElement("btn_closeTrolley");
						oInput1.setValue("");
						sap.ui.getCore().byId("container-com.swl---Main--innergrid1--scanHU").focus();

					},
					error: function (oError) {
						var formTrolley = sap.ui.getCore().byId("container-com.swl---Main--innergrid2--FormTrolley");
						formTrolley.unbindElement("odata");

						var trolleyCont = sap.ui.getCore().byId("container-com.swl---Main--innergrid3--TblTrolleyContent");
						//column list item creation
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{Position}"
							}), new sap.m.Text({
								text: "{Product/MatNR}"
							}), new sap.m.Text({
								text: "{HU/HUIdent}"
							}), new sap.m.Text({
								text: "{HU/HUType}"
							}), new sap.m.Text({
								text: "{Quantity/Quan} {Quantity/Unit}"
							})]
						});

						trolleyCont.setModel(oModel);
						trolleyCont.bindAggregation("items", {
							path: "/ScanTrolleySet(Lgnum='" + lgnum + "',ScanTrolley='')/ScanTrolley_TrolleyContentNav",
							template: oTemplate
						}); //	trolleyCont.bindRows("/ScanTrolley_TrolleyContentNav");
						//trolleyCont.unbindAggregation("items");

						//var oMsg = JSON.parse(oError.responseText);
						var oMsg = oResourceBundle.getText("TROLLEY_CLOSEALL_Fail", "DECO1");
						this.showMessage(oMsg, MessageType.Error);
						that.disableElement("btn_closeTrolley");
					}
				}

			);
			oModel.refresh(true);
		},

		buildStorageBin: function () {
			//debugger;

			var container = sap.ui.getCore().byId("container-com.swl---Main--innergrid1--ShelfDisplay");
			var shelfs = 8;
			var shelfToDisplay = 4;
			var shelfSections = 3;
			var targetShelfSection = 2;

			var count;
			for (count = 1; count <= shelfs; count++) {
				var id = "stack" + count;
				var shelf = new sap.m.FlexBox(id, {
					alignItems: "Start",
					justifyContent: "Center",
					height: "30px",
					width: "70%"
				});
				shelf.addStyleClass("stack");
				if (count === shelfToDisplay) {
					//debugger;
					for (var sections = 1; sections <= shelfSections; sections++) {
						if (sections === targetShelfSection) {
							var innerBoxSelected = new sap.m.FlexBox(id + sections, {
								height: "30px",
								width: "33%",
								alignItems: "Start",
								justifyContent: "Center"
							}).addStyleClass("item2");

							innerBoxSelected.setLayoutData(new sap.m.FlexItemData({
								growFactor: 1
							}));
							shelf.addItem(innerBoxSelected);
						} else {
							var innerBox = new sap.m.FlexBox(id + sections, {
								height: "30px",
								width: "33%",
								alignItems: "Start",
								justifyContent: "Center"
							}).addStyleClass("item1");

							innerBox.setLayoutData(new sap.m.FlexItemData({
								growFactor: 1
							}));
							shelf.addItem(innerBox);
						}
					}
				}
				container.addItem(shelf);
			}

		}
	});
});